import { createBareServer } from '@tomphttp/bare-server-node';
const bareServer = createBareServer('/bare/');

export default bareServer;